from django.db import models

# Create your models here.
class CoursesManager(models.Manager):
    def validator(self, postData):
        errors = {}
        if len(postData['title']) < 1:
            errors["title"] = 'Course name cannot be blank'
        if len(postData['description']) < 1:
            errors["description"] = 'Course description cannot be blank'
        return errors

class Courses(models.Model):
    title = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = CoursesManager()
