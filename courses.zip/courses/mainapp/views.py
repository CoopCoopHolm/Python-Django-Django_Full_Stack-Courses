from django.shortcuts import render, redirect
from django.contrib import messages

from .models import Courses
# Create your views here.
def create(request):
    errors = Courses.objects.validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
            return redirect('/')
    if request.method == 'POST':
        Courses.objects.create(
            title = request.POST['title'],
            description = request.POST['description'],
        )
        return redirect('/')
    return redirect('/')

def index(request):
    context = {
        'all_courses': Courses.objects.all()
    }
    return render(request, "add.html", context)

def delete(request, course_id):
    delete = Courses.objects.get(id=course_id)
    delete.delete()
    return redirect('/')

def remove(request, course_id):
    context = {
        'course': Courses.objects.get(id=course_id)
    } 
    return render(request, 'remove.html', context)
